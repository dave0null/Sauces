Encryption Library
------------------
Author: Bret Taylor (bstaylor@stanford.edu)

This library offers a simple, but suprisingly effective,
method of encrypting text files using bitwise manipulation.
I have included a simple client of the library in "client.c"
which simply takes in the names of an input file, an output
file, and a key, and performs encryption or decryption on
that file.  On UNIX, you can compile this test program using
these commands:

% gcc -c encrypt.c
% gcc -o encrypt client.c encrypt.o

You can then encrypt a file (in this case called "myfile.txt")
to a new, encrypted version of the file (in this
case called "output.enc") using a command like this:

% encrypt -e myfile.txt output.enc k

where 'k' is the character key you wish to use to encrypt the
file with.  The -e switch indicates encryption, whereas the
-d switch indicates decryption.  To decrypt the example file
above to a new file called "normal.txt", you would type

% encrypt -d output.enc normal.txt k

An interesting thing to note is that the -e and -d switches,
using my implementation (which is explained througholy in
encrypt.c), make no difference whatsoever.  I simply wrote
my client this way to preserve the "blind client" relationship
that any client should have with a library.  See encrypt.c for
details.

Hope it is fun to play with.

Bret Taylor
bstaylor@stanford.edu
